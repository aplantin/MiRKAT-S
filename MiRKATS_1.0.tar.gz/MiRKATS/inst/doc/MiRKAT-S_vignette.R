## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----throat--------------------------------------------------------------
# Load the data 
library(MiRKATS, quietly=TRUE)
library(GUniFrac, quietly=TRUE)
data(throat.tree)
data(throat.otu.tab)
data(throat.meta)

# Prepare covariates 
set.seed(1)
Male = rep(0, nrow(throat.meta))
Male[throat.meta$Sex == "Male"] <- 1
Smoker = rep(0, nrow(throat.meta)) 
Smoker[throat.meta$SmokingStatus == "Smoker"] <- 1 

# Simulate outcomes 
# Here, outcome is associated with covariates but unassociated with microbiota
# 33% censoring 
SurvTime <- rexp(60, (1 + Smoker + Male))
CensTime <- rexp(60, 0.75)
Delta <- as.numeric( SurvTime <= CensTime )
ObsTime <- pmin(SurvTime, CensTime)

## ----get-d---------------------------------------------------------------
unifracs <- GUniFrac(throat.otu.tab, throat.tree, alpha=c(0, 0.5, 1))$unifracs
D.weighted <- unifracs[,,"d_1"]  
D.unweighted <- unifracs[,,"d_UW"]
D.generalized <- unifracs[,,"d_0.5"]
D.braycurtis <- as.matrix(vegdist(throat.otu.tab, method="bray"))

## ----d2k-----------------------------------------------------------------
K.weighted <- D2K(D.weighted) 
K.unweighted <- D2K(D.unweighted)
K.generalized <- D2K(D.generalized) 
K.braycurtis <- D2K(D.braycurtis)

## ----MS------------------------------------------------------------------
# use kernel matrix with distance=FALSE 
MiRKATS(kd = K.generalized, distance = FALSE, obstime = ObsTime, delta = Delta, covar = cbind(Male, Smoker))
# equivalently, use distance matrix with distance=TRUE 
MiRKATS(kd = D.generalized, distance = TRUE, obstime = ObsTime, delta = Delta, covar = cbind(Male, Smoker))

## ----perm----------------------------------------------------------------
MiRKATS(kd = K.generalized, distance = FALSE, obstime = ObsTime, delta = Delta, covar = cbind(Male, Smoker), perm=TRUE, nperm=1000)

## ----table, echo=FALSE, message=FALSE, warnings=FALSE, results='asis'----
tabl <- "  
| Distance | Phylogeny? | Abundance? | Other notes | Reference | 
|:---------------|:--------:|:--------:|---------------------------|:-----:|
| Unweighted UniFrac     | √ | X   |  | 1 |
| Weighted UniFrac       | √ | √   |  | 2 | 
| Generalized UniFrac    | √ | (√) | Parameter alpha defines extent to which abundance is taken into account | 3 | 
| Jaccard                | X | X | 1 - (taxa in both)/(taxa in either); typically presence/absence, but can be extended to an abundance-weighted version | 4,5 | 
| Bray-Curtis            | X | √ | Similar to Jaccard, but uses counts | 6 | 
"
cat(tabl) # output the table in a format good for HTML/PDF/docx conversion

